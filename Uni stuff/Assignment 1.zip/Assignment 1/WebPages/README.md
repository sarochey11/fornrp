## index.html - 
This is the main Home Page of my assignment. Main Features; 
- Call to Action.
- IFrame video.

## products.html - 
This is the Products page of my assignment. Main Features; 
- Selection menu for: Hoodies, Zip Up Hoodies, Jumpers, T-Shirts.
- Shop now hovermenu for style

## item.html
This is the item page of my assignment. Main Features;
- Item Colour Picker.
- Change picture to fit the selected colour.
- Quantity Selector.
- Anchor tag which can be used to select another item quicker than going back to the product page.
- Add to cart and valid input checker.

## cart.html
This is the cart page of my assignment. Main Features;
- Automatic cart feature based on localStorage submission from item.html.
- Clear cart function

## style.css
This is the style page for my assignment. Main Purpose;
- Provides styling for; index.html, products.html, item.html, cart.html.

## index.js
This is the main page for JavaScript. Main Purpose;
- Provides functionality for all the other pages.

## Data.js
This is the JS file which contains the formatted version of the data.JSON file.

## JQuery.js
This inisalises and loads JQuery into my root folder. This is then loaded into each HTML sheet

## data.json
Raw JSON file for the products list. Taken and formated from the .CSV file.
