const data = [
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Select Colour",
      "Description": " ",
      "Price": 0.00,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/placeholder.jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Select Colour",
      "Description": " ",
      "Price": 0.00,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/placeholder.jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Select Colour",
      "Description": " ",
      "Price": 0.00,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/placeholder.jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Select Colour",
      "Description": " ",
      "Price": 0.00,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/placeholder.jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Purple",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(1).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Light Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(2).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Green",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(3).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Dark Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(4).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Black",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(5).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Salmon",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(6).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Burgundy",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(7).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Dark Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(8).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Light Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(9).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Slate Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(10).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Orange",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(11).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Teal",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(12).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Navy",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(13).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Orange",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(14).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Creame",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(15).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Lime",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(16).jpg"
    },
    {
      "ItemName": "UCLanHoodie",
      "Colour": "Off Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(17).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Red",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(17).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Charcoal",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(18).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Navy Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(19).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Lighter Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(20).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "New Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(21).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Forest Green",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(22).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Ocean Blue",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(23).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Pink",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(24).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Orange New",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(25).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Black",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(26).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Light Off Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(27).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Rusty Red",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(28).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Slate Grey",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(29).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Bright Green",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(30).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Bright Pink",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(31).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Burgundy New",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(32).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Navy New",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(33).jpg"
    },
    {
      "ItemName": "UCLanZipUpHoodie",
      "Colour": "Bright Green",
      "Description": "Cotton authentic character and practicality are combined in this comfy  warm and luxury zip-up hoodie for students that goes with everything to create casual looks",
      "Price": 39.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/zipuphoodies/hoodie%20(34).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Purple",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(1).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Rusty Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(2).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Water Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(3).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "White",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(4).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Pink",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(5).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Black",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(6).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Old Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(7).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Dark Grey",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(8).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(9).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Brown",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(10).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Green",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(11).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Dark Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(12).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Yellow",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(13).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Light Grey",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(14).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Light Green",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(15).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Old Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(16).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Light Purple",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(17).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Slate Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(18).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Real Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(19).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Old Pink",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(20).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Slate Grey",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(21).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Bright Green",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(22).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Teal",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(23).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Sky Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(24).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Sunshine Pink",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(25).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Bronze",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(26).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Olive Green",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(27).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Bright White Green",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(28).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Navy Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(29).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Rusty Orange",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(30).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Bright Orange",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(31).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Sky Purple",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(32).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Really Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(33).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Plum Purple",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(34).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Dark Purple",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(35).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Vibrant Red",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(36).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Ocean Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(37).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Creame",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(38).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Lighter Blue",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(39).jpg"
    },
    {
      "ItemName": "UCLanLogoJumper",
      "Colour": "Light Grey",
      "Description": "Cotton authentic character and practicality are combined in this winter jumper for students that goes with everything to create casual looks",
      "Price": 29.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/jumpers/jumper%20(40).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Navy Blue New",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(1).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Rusty Red New",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(2).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Burgundy",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(3).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Pink",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(4).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Teal",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(5).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Black",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(6).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Old Red",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(7).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Grey",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(8).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Red",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(9).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Brown",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(10).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Pdark Purple",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(11).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Yellow",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(12).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Mustard Yellow",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(13).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Dark Grey",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(14).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Dark Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(15).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Bright Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(16).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Olive Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(17).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Dark Grey",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(18).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Orange",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(19).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Purple",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(20).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Slate Blue",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(21).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Bright Pink",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(22).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Brightly Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(23).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Lime Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(24).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Ocean Blue",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(25).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Dark Red",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(26).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Another Green",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(27).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Slate Grey",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(28).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Bright Orange",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(29).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Another Purple",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(30).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Real Red",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(31).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Brilliant Blue",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(32).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Creame",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(33).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "Teal Blue",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(34).jpg"
    },
    {
      "ItemName": "UCLanLogoTshirt",
      "Colour": "White",
      "Description": "Cotton authentic character and practicality are combined in this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days",
      "Price": 19.99,
      "ImagePath": "resources/coursework/assignment%201%20resources/images/items/tshirt/tshirt%20(35).jpg"
    }
  ];