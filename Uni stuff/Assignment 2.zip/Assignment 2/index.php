<?php
$title = "Home";

require "global/head.php";
?>
    <div class="container">
        <div class="lto">
            <h2 id="ltoTitle">Limited Timed Offer</h2>
            <div class="ltoContent">
                <?php require 'main.php';
                    /* mysqli_select_db("sean_main", $conn); */
                    $offersRaw = "SELECT * FROM tbl_offers";
                    $offers = mysqli_query($conn, $offersRaw);


                    while ($row = $offers->fetch_assoc()) {
                        if ($row["offer_id"] == 1) {
                            $class = "itoLeft";
                        } elseif ($row["offer_id"] == 2) {
                            $class = "itoCentre";
                        } else {
                            $class = "itoRight";
                        };

                    $ltoContent = '
                        <div class="' . $class . '">
                            <h2 class="itoHeader">'. $row["offer_title"]. '</h2>
                            <p class="itoText">'. $row["offer_dec"]. '</p>
                        </div>

                    ';
                    echo $ltoContent;
                };
                ?>
            </div>

        </div>


        <p class="text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore ipsum animi, voluptatum molestias quasi id iure neque natus consequuntur dolorum corrupti sint expedita accusamus adipisci quo facere odio et tempora? Nisi, obcaecati quod. Quibusdam
            exercitationem deleniti perspiciatis, dolor corrupti perferendis quis iusto placeat optio quisquam doloribus ratione alias porro eveniet impedit itaque possimus atque iste laborum eius eaque aut veritatis. Numquam, similique pariatur tempore
            laboriosam unde totam fugit, libero explicabo, facere laborum est illum. Odit temporibus, quis, quae ducimus a expedita minima odio laborum non nemo omnis impedit doloribus autem? Consequuntur totam nobis quaerat ea, architecto consequatur
            voluptatum deserunt corrupti error ipsum quia minima magnam aspernatur ipsam eum quibusdam corporis odio veniam dolorum fugiat repellat? Quo explicabo voluptatem exercitationem asperiores. Temporibus ipsum doloribus ut dolorum, eius natus.
            Libero provident praesentium nulla, veritatis voluptatem vel eligendi consectetur iure, dolorem sit aperiam vitae sequi. Nesciunt nisi repudiandae ipsum minima voluptates, excepturi sequi.</p>
        <!-- Call to action -->
        <h2 class="calltoaction"><a href="products.php">Check out our products now!</a></h2>

        <div class="video">
            <!-- This is my video -->
            <video width="980" height="450" controls>
                <source src="resources/coursework/assignment%201%20resources/video/together.mp4" type="video/mp4">
            </video>
        </div>
    </div>

<?php
    require "global/footer.php";
?>
