<!DOCTYPE html>

<?php
session_start();
?>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?php echo $title ?></title>
        <!-- Links my index.php to my CSS file -->
        <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>

    <header>
        <!-- Links Bootstrap -->
        <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
        <!-- Links Jquery to sheet -->
        <script src="js/jquery.JS"></script>
        <!-- Links my index.php to my JS file -->
        <script src="js/index.js"></script>
        <!-- Links my data.js file which contains my product information. -->
        <script src="js/data.js"></script>
            <div class="headerinner">
                <a href="index.php" class="logo"><img src="resources/coursework/assignment%201%20resources/images/logo/uclan.png" alt="UCLan logo">
                </a>
                <!-- Navigation bar  -->
                <nav>
                    <ul class="myNav">
                        <!-- This is the start of my navagation bar. Below I have linked my three pages -->
                        <li class="navList"><a href="index.php">Home</a></li>
                        <!-- Links Home page -->
                        <li class="navList"><a href="products.php">Products</a> </li>
                        <!-- Links Products page -->
                        <li class="navList"><a href="cart.php">Cart</a> </li>
                        <!-- Links Cart page -->
                      <?php
                      if(isset($_SESSION["user_id"]))
                      {
                        ?>
                        <li class="navList"><a href="includes/logout.inc.php">Logout</a></li>
                        <li class="navList"><a href="login.php"><?php echo $_SESSION["user_full_name"]; ?></a></li>
                        <?php
                          }
                      else
                          {
                        ?>
                          <li class="navList"><a href="login.php">Login</a></lt>
                        <?php
                          }
                        ?>
                    </ul>
                </nav>
            </div>
            <div class="hamNav">
                <div class="hamFlex">
                    <a href="index.php" class="logo"><img src="resources/coursework/assignment%201%20resources/images/logo/uclan.png" alt="UCLan logo"></a>
                    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                        <img class="hamImage" src="resources/coursework/assignment%201%20resources/images/logo/hamburgerwhite.png" alt="hamBurger">

                    </a>

                </div>

                <div id="myNav">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="cart.php">Cart</a>
                    <?php
                    if(isset($_SESSION["userid"]))
                    {
                      ?>
                      <a href="includes/logout.inc.php">Logout</a></li>
                      <a href="login.php"><?php echo $_SESSION["userid"]; ?></a></li>
                      <?php
                        }
                    else
                        {
                      ?>
                        <a href="login.php">Login</a></lt>
                      <?php
                        }
                      ?>

                </div>
            </div>
            <script>
                function myFunction() {
                    var x = document.getElementById("myNav");
                    if (x.style.display === "block") {
                        x.style.display = "none";
                    } else {
                        x.style.display = "block";
                    }
                }
        </script>
    </header>
