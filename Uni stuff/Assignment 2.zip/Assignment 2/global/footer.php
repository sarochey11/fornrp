    <!-- Footer -->
    <footer>
        <div class="container">
            Created by Sean Roche. Only for use for CO1706 - Assignment 1
        </div>
    </footer>

</body>

</html>