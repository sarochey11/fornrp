<?php
$title = "Cart";

include "global/head.php";
?>
    <div class="cartContainer container">
        <div class="yourCart">
            <h1 class="cartTitle">Your Cart</h1>
            <div class="cartImport">

            </div>
            <!-- Below has been recreated in JS to add reusability -->
            <!-- <div class="cart-header">
                    <div class="cartImage"><img 
                        src="resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(10).jpg"
                        alt="placeholder">
                    </div>
                    <div class="cartLeft">
                        <div class="cartItem">cartItem</div>
                        <div class="cartColour">cartColour</div>
                        <div class="cartQty">cartQty</div>
                    </div>
                    <div class="cartRight">
                        <div class="cartItemPrice">cartItemPrice</div>
                        <div class="cartClearItem">cartClearItem</div>
                    </div>
                </div> -->
        </div>
        <div class="cartTotal">
            <h3 id="cartTotalAmount">Total</h3>
            <div class="cartTotal2">
                <div class="dust-bin"><input type="image" src="resources/coursework/assignment%201%20resources/images/logo/dust-bin.png" alt="dust-bin" id="clearBasket">

                </div>

                <input class="cartCheckout" type="button" onclick="" value="Proceed to checkout!">

            </div>
        </div>
    </div>

<?php
    include "global/footer.php";
?>