<?php
if (isset($_POST["submit"])) {
  // Grabbing the data
  $fullName = $_POST["fullName"];
  $email = $_POST["email"];
  $pwd = $_POST["pwd"];
  $rpwd = $_POST["rpwd"];

  //Instantiate SignupContr class
  include "../classes/dbh.classes.php";
  include "../classes/signup.classes.php";
  include "../classes/signup-contr.classes.php";
  $signup = new SignupContr($fullName, $pwd, $rpwd, $email);

  //Running error handlers amd iser signup
  $signup->signupUser;
  //Going back to front page
  header("location: ../index.php?error=none");
}
