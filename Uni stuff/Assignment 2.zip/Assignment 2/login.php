<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Login/Signup</title>
        <!-- Links my adminarea/login.php to my CSS file -->
        <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="includes/login.css">
    </head>
    <body>
      <header>
          <!-- Links Bootstrap -->
          <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
          <!-- Links Jquery to sheet -->
          <script src="/js/jquery.JS"></script>
          <!-- Links my adminarea/login.php to my JS file -->
          <script src="/js/index.js"></script>
          <!-- Links my data.js file which contains my product information. -->
          <script src="/js/data.js"></script>
      </header>


      <div class="container login-container">
        <div class="calltoaction" style="background:firebrick">
          <a href="index.php" style="background:firebrick">Return</a>
        </div>

            <div class="row">
                <div class="col-md-6 login-form-1">
                    <h3>Login</h3>
                    <form action="includes/login.inc.php" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Email *" name="fullName" />
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Your Password *" name="pwd" />
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btnSubmit" name="submit" value="true">LOGIN</button>
                        </div>
                        <div class="form-group">
                            <a href="#" class="ForgetPwd">Forget Password?</a>
                        </div>
                    </form>
                </div>
                <div class="col-md-6 login-form-2">
                    <h3>Signup</h3>
                    <form action="includes/signup.inc.php" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" name="fullName" placeholder="Your Full Name *"/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="email" placeholder="Your Email *"/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="pwd" placeholder="Your Password *"/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="rpwd" placeholder="Repeat Password *"/>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btnSubmit" name="submit">SIGN UP</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>



    </body>
