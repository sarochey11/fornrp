<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// $servername = "sean.k1.bandicoot.co.uk";
// $username = "sean_1";
// $password = "AD)3%Zg4QOyX>)!yf[9D";
// $dbname = "sean_main";

$servername = "localhost";
$username = "sroche4";
$password = "7ZkvtKLW";
$dbname = "sroche4";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
};



// if(isset($_POST['submit'])){
//   $product = $conn->real_escape_string($_POST['product1']);
//   $query = "SELECT * FROM tbl_products WHERE product_type LIKE " . "'$product'";
//   $dbresult=mysqli_query($conn, $query);

//   return $query;
// }

?>
