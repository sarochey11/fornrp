<?php
error_reporting(0);
//Setting session start
session_start();

$total=0;

//Database connection, replace with your connection string.. Used PDO
$conn = new PDO("mysql:host=localhost;dbproduct_type=tutsplanet", 'root', '');		
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


//get action string
$action = isset($_GET['action'])?$_GET['action']:"";

//Add to cart
if($action=='addcart' && $_SERVER['REQUEST_METHOD']=='POST') {
	
	//Finding the product by code
	$query = "SELECT * FROM tbl_products WHERE product_title=:product_title";
	$stmt = $conn->prepare($query);
	$stmt->bindParam('product_title', $_POST['product_title']);
	$stmt->execute();
	$product = $stmt->fetch();
	
	$currentQty = $_SESSION['tbl_products'][$_POST['product_title']]['qty']+1; //Incrementing the product qty in cart
	$_SESSION['tbl_products'][$_POST['product_title']] =array('qty'=>$currentQty,'product_type'=>$product['product_type'],'product_image'=>$product['product_image'],'product_price'=>$product['product_price']);
	$product='';
	header("Location:shopping-cart.php");
}

//Empty All
if($action=='emptyall') {
	$_SESSION['tbl_products'] =array();
	header("Location:shopping-cart.php");	
}

//Empty one by one
if($action=='empty') {
	$product_title = $_GET['product_title'];
	$tbl_products = $_SESSION['tbl_products'];
	unset($tbl_products[$product_title]);
	$_SESSION['tbl_products']= $tbl_products;
	header("Location:shopping-cart.php");	
}


 
 
 //Get all tbl_products
$query = "SELECT * FROM tbl_products";
$stmt = $conn->prepare($query);
$stmt->execute();
$tbl_products = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta product_type="viewport" content="width=device-width, initial-scale=1">
<title>PHP registration form</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container" style="width:600px;">
  <?php if(!empty($_SESSION['tbl_products'])):?>
  <nav class="navbar navbar-inverse" style="background:#04B745;">
    <div class="container-fluid pull-left" style="width:300px;">
      <div class="navbar-header"> <a class="navbar-brand" href="#" style="color:#FFFFFF;">Shopping Cart</a> </div>
    </div>
    <div class="pull-right" style="margin-top:7px;margin-right:7px;"><a href="shopping-cart.php?action=emptyall" class="btn btn-info">Empty cart</a></div>
  </nav>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>product_image</th>
        <th>product_type</th>
        <th>product_price</th>
        <th>Qty</th>
        <th>Actions</th>
      </tr>
    </thead>
    <?php foreach($_SESSION['tbl_products'] as $key=>$product):?>
    <tr>
      <td><img src="<?php print $product['product_image']?>" width="50"></td>
      <td><?php print $product['product_type']?></td>
      <td>$<?php print $product['product_price']?></td>
      <td><?php print $product['qty']?></td>
      <td><a href="shopping-cart.php?action=empty&product_title=<?php print $key?>" class="btn btn-info">Delete</a></td>
    </tr>
    <?php $total = $total+$product['product_price'];?>
    <?php endforeach;?>
    <tr><td colspan="5" align="right"><h4>Total:$<?php print $total?></h4></td></tr>
  </table>
  <?php endif;?>
  <nav class="navbar navbar-inverse" style="background:#04B745;">
    <div class="container-fluid">
      <div class="navbar-header"> <a class="navbar-brand" href="#" style="color:#FFFFFF;">tbl_products</a> </div>
    </div>
  </nav>
  <div class="row">
    <div class="container" style="width:600px;">
      <?php foreach($tbl_products as $product):?>
      <div class="col-md-4">
        <div class="thumbnail"> <img src="<?php print $product['product_image']?>" alt="Lights">
          <div class="caption">
            <p style="text-align:center;"><?php print $product['product_type']?></p>
            <p style="text-align:center;color:#04B745;"><b>$<?php print $product['product_price']?></b></p>
            <form method="post" action="shopping-cart.php?action=addcart">
              <p style="text-align:center;color:#04B745;">
                <button type="submit" class="btn btn-warning">Add To Cart</button>
                <input type="hidden" product_type="product_title" value="<?php print $product['product_title']?>">
              </p>
            </form>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>
</body>
</html>