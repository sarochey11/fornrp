<?php
$title = "Product";

require "global/head.php";
?>

    <!-- Main container for my products -->
    <div class="container">
        <div class="searchBar">
          <form class="" method="post">
            <input type="text" placeholder="Search..." id="search" name="searchBox">
            <button type="submit" id="submitButton" name="searchItem">Search</button>
            <div class="searchButtons">
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="product" id="inlineCheckbox1" value="UCLan Hoodie">
                  <label class="form-check-label" for="inlineCheckbox1">Hoodies</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="product" id="inlineCheckbox2" value="UCLan Zip Up Hoodie">
                  <label class="form-check-label" for="inlineCheckbox2">Zip Up Hoodies</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="product" id="inlineCheckbox3" value="UCLan Logo Jumper">
                  <label class="form-check-label" for="inlineCheckbox3">Jumpers</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="checkbox" name="product" id="inlineCheckbox4" value="UCLan Logo T Shirt">
                  <label class="form-check-label" for="inlineCheckbox4">T-Shirts</label>
                </div>
                <button type="submit" value="click" name="submit" class="btn btn-outline-light">Submit</button>
            </form>


            </div>

        </div>
        <div class="row">
        <?php require 'main.php';
            /* mysqli_select_db("sean_main", $conn); */
            if (isset($_POST['searchItem'])) {
              $searchBox = $conn->real_escape_string($_POST['searchBox']);
              $query = "SELECT * FROM tbl_products WHERE product_type LIKE " . "  '%$searchBox%' OR product_title LIKE " . "'%$searchBox%'" ;
              $dbresult=mysqli_query($conn, $query);
            }
            else {
              $query = "SELECT * FROM tbl_products";
            }

            if(isset($_POST['submit'])){
              $product = $conn->real_escape_string($_POST['product']);
              $query = "SELECT * FROM tbl_products WHERE product_type LIKE " . "'$product'";
              $dbresult=mysqli_query($conn, $query);
            }
            //$productsRaw = "SELECT * FROM tbl_products";
            $productsRaw = $query;
            $productsData = mysqli_query($conn, $productsRaw);
            while ($row = $productsData->fetch_assoc()) {
                $products = '
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="row g-0">
                        <div class="col-md-4">
                            <img src="'. $row["product_image"] .'" class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                            <div class="cardInfo">
                                <h5 class="card-title">'. $row["product_type"] .'</h5>
                                <span class="badge bg-secondary">&#163;' .$row["product_price"]. '</span>
                            </div>
                            <h6 class="card-text">'. $row["product_title"] .'</h6>
                            <a href="item.php?id='. $row["product_id"] .'" class="btn btn-outline-success mt-3">More Information</a>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                ';
                echo $products;
            };
        ?>
        </div>
    </div>
<?php
    require "global/footer.php";
?>
