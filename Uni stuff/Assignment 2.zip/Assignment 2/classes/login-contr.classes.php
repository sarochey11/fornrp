<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

class LoginContr extends Login {

  private $fullName;
  private $pwd;
  private $rpwd;
  private $email;

  public function _construct($fullName, $pwd) {
     $this->fullName = $fullname;
     $this->pwd = $pwd;
  }

  public function loginUser() {
    if($this->emptyInput() == false) {
      //echo "Empty input!";
      header("location: ../index.php?error=emptyinput");
      exit();
    }

    $this->getUser($this->fullName, $this->pwd);
  }

  private function emptyInput() {
    if (empty($this->$fullName) || empty($this->pwd)) {
      $result = false;
    } else {
      $result = true;
    }
    return $result;
  }
}
