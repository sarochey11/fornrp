<?php

class Signup extends Dbh {

  protected function setUser($fullName, $pwd, $email) {
    $stmt = $this->connect()->prepare('INSERT INTO tbl_users (user_full_name, user_email, user_pass) VALUES (?, ?, ?);');

    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT)

    if(!$stmt->execute(array($fullName, $hashedPwd, $email))) {
      $stmt = null;
      header("location: ../index.php?error=stmtfailed");
      exit();
    }

    $stmt = null;
  }

  protected function checkUser($fullName, $email) {
    $stmt = $this->connect()->prepare('SELECT user_full_name FROM tbl_users WHERE user_full_name = ? OR user_email = ?;');

    if(!$stmt->execute(array($fullName, $email))) {
      $stmt = null;
      header("location: ../index.php?error=stmtfailed");
      exit();
    }

    $resultCheck;
    if($stmt->rowCount() > 0) {
      $resultCheck = false;
    } else {
      $resultCheck = true;
    }

    return $resultCheck;
  }
}
