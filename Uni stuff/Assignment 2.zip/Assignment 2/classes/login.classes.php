<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

class Login extends Dbh {

  protected function getUser($fullName, $pwd) {
    $stmt = $this->connect()->prepare('SELECT user_pass FROM tbl_users VALUES user_full_name = ? OR user_email = ?;');

    if(!$stmt->execute(array($fullName, $hashedPwd))) {
      $stmt = null;
      header("location: ../index.php?error=stmtfailed");
      exit();
    }

    if($stmt->rowCount() == 0)
    {
      $stmt = null;
      header("location: ../index.php?error=usernotfound");
      exit();
    }

    $pwdHashed = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $checkPwd = password_verify($pwd, $pwdHashed[0]["user_pass"]);

    if($checkPwd == false)
    {
      $stmt = null;
      header("location: ../index.php?error=usernotfound");
      exit();
    } elseif($checkPwd == true)
    {
      $stmt = $this->connect()->prepare('SELECT * FROM tbl_users WHERE user_full_name = ? OR user_email = ? AND user_pass = ?;');

      if(!$stmt->execute(array($fullName,$email, $hashedPwd))) {
        $stmt = null;
        header("location: ../index.php?error=stmtfailed");
        exit();
      }

      if($stmt->rowCount() == 0)
      {
        $stmt = null;
        header("location: ../index.php?error=usernotfound");
        exit();
      }

      $user = $stmt ->fetchAll(PDO::FETCH_ASSOC);
      session_start();
      $_SESSION["userid"] = $user[0]["user_id"];
      $_SESSION["userid"] = $user[0]["user_full_name"];

      $stmt = null;
    }

    $stmt = null;
  }

}
