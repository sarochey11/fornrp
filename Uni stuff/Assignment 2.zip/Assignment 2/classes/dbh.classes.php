<?php

class Dbh {

  protected function connect() {
    try {
      // $username = "sean_1";
      // $password = "AD)3%Zg4QOyX>)!yf[9D";
      // $dbh = new PBO('mysoli:host=sean.k1.bandicoot.co.uk;dbname=tbl_users');

      $username = "sroche4";
      $password = "7ZkvtKLW";
      $dbh = new PBO('mysoli:host=localhost;dbname=tbl_users');
      return $dbh;
    }
    catch (PDOEception $e)
    {
      echo "Error!: " . $e->getMessage() . "<br/>";
      die();
    }
  }
}
