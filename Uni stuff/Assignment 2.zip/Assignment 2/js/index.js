let colourNameSel = null
let itemID = 0
let finalCart = null
let cartTotal = 0
let numberCart = 0

$(document).ready(function() {


    $(".shopProduct").click(function() {
        sessionStorage.removeItem("product");
        sessionStorage.setItem("product", $(this).data("item"));

    });

    $(".anchorProduct").click(function() {
        sessionStorage.removeItem("product");
        sessionStorage.setItem("product", $(this).data("item"));

    });

    $("#colourList").change(function() {
        colourNameSel = $("#colourList option:selected").val()
        productSelected = sessionStorage.getItem("product")

        data.forEach((item) => {
            if (item.Colour == colourNameSel && productSelected == item.ItemName) {
                imageLink = item.ImagePath
                document.getElementById("changeImg").src = imageLink;
                console.log(imageLink)

            }
        });
    });

    $("#cartForm").submit(function() {
        let colour = $("#colourList option:selected").val()
        if (colour != "Select Colour") {
            let colour = $("#colourList option:selected").val()
            let qty = $("#qty").val()
            let price = $("#price").text()
            let cartJSON = localStorage.getItem("cart")
            let cart = []
            if (cartJSON) {
                cart = JSON.parse(cartJSON)
            } else {
                cart = []
            }
            let item = sessionStorage.getItem("product")
            let itemCart = {
                item,
                price,
                qty,
                colour
            }

            cart.push(itemCart)
            let newCartJSON = JSON.stringify(cart)
            localStorage.setItem("cart", newCartJSON);
            $("#itemInCart").text(numberCart)

        } else {
            alert("Invaild Entry!")
        }
    });




    $(function() {
        if ($('body').is('.cartPage')) {
            cartGrab()
        }
    });

    function cartGrab() {
        finalCart = JSON.parse(localStorage.getItem("cart"))

        for (var i = 0; i < finalCart.length; i++) {
            var product = finalCart[i]
            let itemitem = product.item
            let colour = product.colour
            let qty = product.qty
            let price = product.price
            cartTotal = parseFloat(price) + cartTotal


            var cartItem = `
            <div class="cart-header">
                <div class="cartImage"><img src="resources/coursework/assignment%201%20resources/images/items/hoodies/hoodie%20(10).jpg"></div>
                <div class="cartLeft">
                    <div class="cartItem">${itemitem}</div>
                    <div class="cartColour"> Colour: ${colour}</div>
                    <div class="cartQty">Amount: ${qty}</div>
                </div>
                <div class="cartRight">
                    <div class="cartItemPrice">Unit Price: £${price}</div>
                </div>
            </div>
        `;
            $('.cartImport').prepend(cartItem)
        }
        $("#cartTotalAmount").text("Total: " + cartTotal)
    }

    $("#clearBasket").click(function() {
        let isExecuted = confirm("Are you sure you want to clear your basket?")
        console.log(isExecuted); // OK = true, Cancel = false
        localStorage.clear();
        location.reload()
    });
})


// New JS
function toggleSignup(){
   document.getElementById("login-toggle").style.backgroundColor="#fff";
    document.getElementById("login-toggle").style.color="#222";
    document.getElementById("signup-toggle").style.backgroundColor="firebrick";
    document.getElementById("signup-toggle").style.color="#fff";
    document.getElementById("login-form").style.display="none";
    document.getElementById("signup-form").style.display="block";
}

function toggleLogin(){
    document.getElementById("login-toggle").style.backgroundColor="firebrick";
    document.getElementById("login-toggle").style.color="#fff";
    document.getElementById("signup-toggle").style.backgroundColor="#fff";
    document.getElementById("signup-toggle").style.color="#222";
    document.getElementById("signup-form").style.display="none";
    document.getElementById("login-form").style.display="block";
}
