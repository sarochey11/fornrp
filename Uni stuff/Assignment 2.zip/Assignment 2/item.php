<?php
$title = "Item";
require 'main.php';
require "global/head.php";

?>

<div class="container">

<?php
$url = $_SERVER['REQUEST_URI'];
$components = parse_url($url);
parse_str($components['query'], $results);
$query = "SELECT * FROM tbl_products WHERE product_id =" . $results['id'];
$productsData = mysqli_query($conn, $query);
$row = $productsData->fetch_assoc();
$item = '
<div class="containerInformation container">
    <div class="imageInformation"><img id="changeImg" src="'. $row["product_image"] .'" alt="#########"></div>
    <div class="productInformation">
        <div class="productBox">
            <h2 class="productTitle">'. $row["product_type"] .'</h2>
            <p id="description"> '. $row["product_desc"] .'</p>
        </div>
        <form id="cartForm">
            <input type="hidden" name="price" id="inputPrice">
            <h3 class="colourInformation">Colour: '. $row["product_title"] .'
            </h3>

            <div class="flexcontainer">
                <div class="qtyInformation"><label for="qty">Qty:</label>
                    <label><input type="number" id="qty" name="inputQuantity" min="1" max="5" data-item = "qtyData" value="1"></label>
                </div>
                <div class="priceInformation">
                    <p>Price: £'. $row["product_price"] .'</p>

                </div>
            </div>
            <div class="addToCartInformaion">
                <input type="hidden" name="itemID" id="itemID">
                <input id="addToCart" type="submit" value="Add to Cart!">
            </div>
        </form>
    </div>
</div>
';
echo $item;
  ?>
</div>
</div>

</div>

<?php
    require "global/footer.php";
?>
